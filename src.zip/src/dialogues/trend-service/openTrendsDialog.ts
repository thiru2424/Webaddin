export function openTrendsDialog(): void {
  Office.context.ui.displayDialogAsync("https://localhost:3000/trends.html", { height: 80, width: 65 });
}
