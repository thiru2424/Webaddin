export function openTrendsDialog(): void {
}
