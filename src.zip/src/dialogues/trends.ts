/* global Office, document, window, localStorage */

Office.onReady(() => {
  setupEventListeners();
  initializeData();
  console.log("listening12");

  const dateOption = document.getElementById("dateOption") as HTMLSelectElement;
  const startDate = document.getElementById("startDate") as HTMLInputElement;
  const endDate = document.getElementById("endDate") as HTMLInputElement;

  const startDateHead = document.getElementById("startHead") as HTMLElement;
  const endDateHead = document.getElementById("endHead") as HTMLElement;

  (window as any).closeTrendsDialog = closeTrendsDialog;

  const today = new Date().toISOString().split("T")[0];
  startDate.max = today;
  endDate.max = today;
  console.log("listening34");

  dateOption.addEventListener("change", () => {
    const selected = dateOption.value;
     const today = new Date().toISOString().split("T")[0];
  startDate.max = today;
    startDate.min = "";

    startDate.classList.remove("hidden");
    endDate.classList.remove("hidden");
    startDateHead.classList.remove("hidden");
    endDateHead.classList.remove("hidden");
    startDateHead.textContent = "From";

    if (selected === "prior") {
      startDate.classList.add("hidden");
      endDate.classList.add("hidden");
      startDateHead.classList.add("hidden");
      endDateHead.classList.add("hidden");
    } else if (selected === "specific") {
      startDate.classList.remove("hidden");
      endDate.classList.add("hidden");
      startDateHead.classList.remove("hidden");
      endDateHead.classList.add("hidden");
      startDateHead.textContent = "Date";
    }
  });
 startDate.addEventListener("change", () => {
  if (startDate.value) {
    const from = new Date(startDate.value);
    from.setDate(from.getDate() + 1);
    endDate.min = from.toISOString().split("T")[0];
  } else {
    endDate.removeAttribute("min");
  }
  validateDates();
});

endDate.addEventListener("change", () => {
  if (endDate.value) {
    const to = new Date(endDate.value);
    to.setDate(to.getDate() - 1);
    startDate.max = to.toISOString().split("T")[0];
  } else {
    startDate.removeAttribute("max");
  }
  validateDates();
});


  function validateDates(): boolean {
    const from = new Date(startDate.value);
    const to = new Date(endDate.value);
    const today = new Date();
    const mode = dateOption.value;
    const errorBox = document.getElementById("dateError");

    // Clear any previous messages
    errorBox!.textContent = "";

    // Normalize time
    from.setHours(0, 0, 0, 0);
    to.setHours(0, 0, 0, 0);
    today.setHours(0, 0, 0, 0);

    if (mode === "prior") {
      return true;
    }

    if (mode === "specific") {
      if (!startDate.value) {
        errorBox!.textContent = "Please select a date.";
        return false;
      }
      if (from > today) {
        errorBox!.textContent = "Date cannot be in the future.";
        return false;
      }
      return true;
    }

    if (mode === "range") {
      if (!startDate.value || !endDate.value) {
        errorBox!.textContent = "select both dates.";
        return false;
      }
      if (from > today || to > today) {
        errorBox!.textContent = "Dates cannot be in the future.";
        return false;
      }
      if (to < from) {
        errorBox!.textContent = "End date must be after Start date.";
        return false;
      }
      return true;
    }

    return true;
  }
});

function getLocalStorageData(key: string) {
  return JSON.parse(localStorage.getItem(key) || "[]");
}
function closeTrendsDialog(): void {
  Office.context.ui.messageParent(JSON.stringify({ type: "CLOSE_DIALOG" }));
}

function initializeData() {
  console.log("🔍 Initializing Data...");
  const accountData = getLocalStorageData("accountList");
  const currencyData = getLocalStorageData("currencyList");

  console.log("✅ Retrieved accountList:", accountData);
  console.log("✅ Retrieved currencyList:", currencyData);

  // Only one dropdown: filterCurrency
  populateDropdown(document.getElementById("filterCurrency"), "currencyList");

  renderTable(accountData, getSortKey());
  updateAccountCount();
  sortTable("available-accounts", accountData);
}

function populateDropdown(dropdown: HTMLElement | null, storageKey: string) {
  if (!dropdown) return;
  const items = getLocalStorageData(storageKey);
  console.log(`📦 Populating dropdown for key: ${storageKey}`, items);

  items.forEach((item: any) => {
    const option = document.createElement("option");
    option.value = item.currency || item; // Support both object or string format
    option.textContent = item.currency || item;
    dropdown.appendChild(option);
  });
}

function renderTable(data: any[], viewBy: string) {
  console.log(`📋 Rendering table with ${data.length} records, view by: ${viewBy}`);
  const tableBody = document.getElementById("available-accounts")!.querySelector("tbody")!;
  tableBody.innerHTML = "";
  data.forEach((account) => {
    const row = document.createElement("tr");
    row.innerHTML = `<td>${viewBy === "accountName" ? account.accountName : account.accountNumber}</td><td>${account.currency}</td>`;
    tableBody.appendChild(row);
  });
}

function applyFilters() {
  const accountsList = getLocalStorageData("accountList");
  const filterCurrency = (document.getElementById("filterCurrency") as HTMLSelectElement).value;
  const filterAccount = (document.getElementById("filterAccount") as HTMLInputElement).value.toLowerCase();
  const filterAccName = (document.getElementById("filterAccountName") as HTMLInputElement).value.toLowerCase();

  const filtered = accountsList.filter(
    (account) =>
      (!filterCurrency || filterCurrency === "All" || account.currency === filterCurrency) &&
      (!filterAccount || account.accountNumber.toString().includes(filterAccount)) &&
      (!filterAccName || account.accountName.toLowerCase().includes(filterAccName))
  );

  renderTable(filtered, getSortKey());
}

function removeFilters() {
  (document.getElementById("filterCurrency") as HTMLSelectElement).value = "All";
  (document.getElementById("filterAccount") as HTMLInputElement).value = "";
  (document.getElementById("filterAccountName") as HTMLInputElement).value = "";
  renderTable(getLocalStorageData("accountList"), getSortKey());
}

function setupEventListeners() {
  document.getElementById("applyFilter")!.addEventListener("click", applyFilters);
  document.getElementById("removeFilter")!.addEventListener("click", removeFilters);
  document.getElementById("view-account-number")!.addEventListener("change", handleViewChange);
  document.getElementById("view-account-name")!.addEventListener("change", handleViewChange);

  setupTableListeners("available-accounts", "selected-accounts");
}

function setupTableListeners(availableId: string, selectedId: string) {
  const available = document.getElementById(availableId)!.querySelector("tbody")!;
  const selected = document.getElementById(selectedId)!.querySelector("tbody")!;

  available.addEventListener("click", (e) => toggleRowSelection(e));
  selected.addEventListener("click", (e) => toggleRowSelection(e));

  document.getElementById("add-btn")!.addEventListener("click", () => moveSelected(available, selected));
  document.getElementById("add-all-btn")!.addEventListener("click", () => moveAll(available, selected));
  document.getElementById("remove-btn")!.addEventListener("click", () => moveSelected(selected, available));
  document.getElementById("remove-all-btn")!.addEventListener("click", () => moveAll(selected, available));
}

function toggleRowSelection(event: MouseEvent) {
  const row = (event.target as HTMLElement).closest("tr");
  if (!row) return;

  if (event.ctrlKey || event.metaKey) {
    row.classList.toggle("selected");
  } else {
    const siblings = row.parentElement!.querySelectorAll(".selected");
    siblings.forEach((sib) => sib.classList.remove("selected"));
    row.classList.add("selected");
  }

  updateAccountCount();
}

function moveSelected(from: HTMLElement, to: HTMLElement) {
  from.querySelectorAll(".selected").forEach((row) => {
    row.classList.remove("selected");
    to.appendChild(row);
  });
  updateAccountCount();
}

function moveAll(from: HTMLElement, to: HTMLElement) {
  Array.from(from.children).forEach((row) => {
    row.classList.remove("selected");
    to.appendChild(row);
  });
  updateAccountCount();
}

function updateAccountCount() {
  const available = document.getElementById("available-accounts")!.querySelector("tbody")!;
  const selected = document.getElementById("selected-accounts")!.querySelector("tbody")!;
  document.getElementById("accounts-total")!.textContent = `${available.children.length} Accounts`;
  document.getElementById("accounts-selected")!.textContent =
    `${available.querySelectorAll(".selected").length} Selected`;
  document.getElementById("accounts-total-sel")!.textContent = `${selected.children.length} Accounts`;
  document.getElementById("accounts-selected-sel")!.textContent =
    `${selected.querySelectorAll(".selected").length} Selected`;
}

function getSortKey(): string {
  return (document.getElementById("view-account-name") as HTMLInputElement).checked ? "accountName" : "accountNumber";
}

function handleViewChange() {
  const accountsList = getLocalStorageData("accountList");
  renderTable(accountsList, getSortKey());
}

function sortTable(tableId: string, dataList: any[]) {
  const headers = document.querySelectorAll(`#${tableId} thead th`);
  headers.forEach((header, index) => {
    let ascending = true;
    header.addEventListener("click", () => {
      const sortKey = index === 0 ? getSortKey() : "currency";
      dataList.sort((a, b) => {
        const aVal = typeof a[sortKey] === "string" ? a[sortKey].toLowerCase() : a[sortKey];
        const bVal = typeof b[sortKey] === "string" ? b[sortKey].toLowerCase() : b[sortKey];
        return ascending ? (aVal > bVal ? 1 : -1) : aVal < bVal ? 1 : -1;
      });
      ascending = !ascending;
      renderTable(dataList, sortKey);
    });
  });
}
